(function () {

	var namespace = "com.sap.trackandtrace.webapp";

	sap.ui.controller(namespace + ".ext.controller.GeoMap", {});
}());